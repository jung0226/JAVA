
public class SuggestVO {
	private int suggest_num;
	private String suggest_title;
	private String suggest_content;
	private int resident_num;
	private String answer_title;
	private String answer_content;
	private String answer_writer;
	private String answer_write_date;

	public SuggestVO() {  }

	public int getSuggest_num() {
		return suggest_num;
	}

	public void setSuggest_num(int suggest_num) {
		this.suggest_num = suggest_num;
	}

	public String getSuggest_title() {
		return suggest_title;
	}

	public void setSuggest_title(String suggest_title) {
		this.suggest_title = suggest_title;
	}

	public String getSuggest_content() {
		return suggest_content;
	}

	public void setSuggest_content(String suggest_content) {
		this.suggest_content = suggest_content;
	}

	public int getResident_num() {
		return resident_num;
	}

	public void setResident_num(int resident_num) {
		this.resident_num = resident_num;
	}

	public String getAnswer_title() {
		return answer_title;
	}

	public void setAnswer_title(String answer_title) {
		this.answer_title = answer_title;
	}

	public String getAnswer_content() {
		return answer_content;
	}

	public void setAnswer_content(String answer_content) {
		this.answer_content = answer_content;
	}

	public String getAnswer_writer() {
		return answer_writer;
	}

	public void setAnswer_writer(String answer_writer) {
		this.answer_writer = answer_writer;
	}

	public String getAnswer_write_date() {
		return answer_write_date;
	}

	public void setAnswer_write_date(String answer_write_date) {
		this.answer_write_date = answer_write_date;
	}
	
	

}
